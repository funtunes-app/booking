// =============================================================================
// FunTunes Main App
// =============================================================================
const { useState, useRef, useEffect, useCallback } = React;

const STEP_LABELS = ["Customer","Payment","Session","Review"];
const STEP_ICONS = ["👤","💳","⏰","✅"];

function App() {
  const [screen,setScreen] = useState("home");
  const [step,setStep] = useState(0);
  const [entryType,setEntryType] = useState("funzone");
  const [form,setFormState] = useState(getDefaultForm());
  const [errors,setErrors] = useState({});
  const [focusedField,setFocusedField] = useState(null);
  const [shakeStep,setShakeStep] = useState(false);
  const [todayEntries,setTodayEntries] = useState([]);
  const [loading,setLoading] = useState(false);
  const [saving,setSaving] = useState(false);
  const [showSuccess,setShowSuccess] = useState(false);
  const [editTarget,setEditTarget] = useState(null);
  const [toast,setToast] = useState(null);
  const containerRef = useRef(null);

  function getDefaultForm() {
    const n=new Date();
    return {customerName:"",amount:CONFIG.DEFAULT_AMOUNT,mop:CONFIG.DEFAULT_MOP,numKids:1,hours:"1",
      timeIn:`${String(n.getHours()).padStart(2,"0")}:${String(n.getMinutes()).padStart(2,"0")}`,
      socks:0,socksMop:"",phone:"",dob:"",date:n.toISOString().slice(0,10)};
  }

  const set = useCallback((key,val) => {
    setFormState(f=>({...f,[key]:val}));
    setErrors(e=>({...e,[key]:undefined}));
  },[]);

  const showToastMsg = (msg,type) => { setToast({msg,type:type||"info"}); setTimeout(()=>setToast(null),3000); };

  useEffect(()=>{ fetchToday(); },[]);

  async function fetchToday() {
    setLoading(true);
    try {
      const res = await api.readToday();
      if (res.success) setTodayEntries(res.data||[]);
      else showToastMsg("Sheet error: "+(res.error||"unknown"),"error");
    } catch(e) { console.error("Fetch:",e); showToastMsg("Could not reach Google Sheet","error"); }
    finally { setLoading(false); }
  }

  const computeTimeOut = (timeIn,hours) => {
    if(!timeIn) return "";
    const [h,m]=timeIn.split(":").map(Number);
    const dur=parseFloat(hours)||1;
    const t=h*60+m+dur*60;
    return `${String(Math.floor(t/60)%24).padStart(2,"0")}:${String(Math.round(t%60)).padStart(2,"0")}`;
  };

  const totalAmount = (parseInt(form.amount)||0)*form.numKids + form.socks*form.numKids;

  const validate = (s) => {
    const errs={};
    if(s===0&&!form.customerName.trim()) errs.customerName="Required";
    if(s===1&&(!form.amount||parseInt(form.amount)<=0)) errs.amount="Enter amount";
    if(s===1&&!form.mop) errs.mop="Select mode";
    setErrors(errs);
    if(Object.keys(errs).length){setShakeStep(true);setTimeout(()=>setShakeStep(false),500);}
    return !Object.keys(errs).length;
  };

  const next = () => { if(validate(step)){setStep(s=>Math.min(s+1,3));containerRef.current?.scrollTo({top:0,behavior:"smooth"});} };
  const prev = () => setStep(s=>Math.max(s-1,0));

  async function submitEntry() {
    const entry={...form,entryType,timeOut:computeTimeOut(form.timeIn,form.hours),timing:`${form.timeIn} to ${computeTimeOut(form.timeIn,form.hours)}`,amount:parseInt(form.amount)||0};
    setSaving(true);
    try {
      const res=await api.addEntry(entry);
      if(res.success){showToastMsg("Saved to Google Sheet!","success");setShowSuccess(true);fetchToday();}
      else showToastMsg("Sheet error: "+(res.error||"unknown"),"error");
    } catch(e){console.error("Save:",e);showToastMsg("Could not save — check internet","error");}
    finally{setSaving(false);}
  }

  function handleEdit(entry) {
    setEditTarget(entry);
    setFormState({
      customerName:entry.customerName||entry["Customer name"]||"",
      amount:String(entry.amount||entry["Amount"]||300),
      mop:entry.mop||entry["MOP"]||CONFIG.DEFAULT_MOP,
      numKids:parseInt(entry.numKids||entry["No of kids"]||1),
      hours:entry.hours||entry["Hours"]||"1",
      timeIn:(entry.timing||entry["Timing"]||"").split(" to ")[0]||"",
      socks:parseInt(entry.socks||entry["Socks"]||0)||0,
      socksMop:entry.socksMop||entry["MOP - Socks"]||"",
      phone:String(entry.phone||entry["Phone number"]||""),
      dob:entry.dob||entry["DOB"]||"",
      date:entry.date||new Date().toISOString().slice(0,10),
    });
    setEntryType(entry.entryType||entry["Entry Type"]||"funzone");
    setStep(0); setScreen("form");
  }

  async function handleUpdateSubmit() {
    const entry={...form,entryType,timeOut:computeTimeOut(form.timeIn,form.hours),timing:`${form.timeIn} to ${computeTimeOut(form.timeIn,form.hours)}`,amount:parseInt(form.amount)||0,slNo:editTarget?.["Sl.no"]||editTarget?.["SI. No"]||editTarget?.["S.no"]||""};
    if(!editTarget?._rowIndex){showToastMsg("Cannot identify row","error");resetForm();return;}
    setSaving(true);
    try {
      const res=await api.updateEntry(editTarget._tab||"",editTarget._rowIndex,entry);
      if(res.success){showToastMsg("Updated!","success");fetchToday();}else showToastMsg("Error: "+(res.error||"unknown"),"error");
    } catch(e){console.error("Update:",e);showToastMsg("Could not update","error");}
    finally{setSaving(false);resetForm();}
  }

  async function handleDelete(entry) {
    if(!entry._rowIndex){showToastMsg("Cannot identify row","error");return;}
    const months=["January","February","March","April","May","June","July","August","September","October","November","December"];
    const d=new Date();
    const tab=entry._tab||`Funzone - ${months[d.getMonth()]} ${d.getFullYear()}`;
    setSaving(true);
    try {
      const res=await api.deleteEntry(tab,entry._rowIndex);
      if(res.success){showToastMsg("Deleted","info");fetchToday();}else showToastMsg("Error: "+(res.error||"unknown"),"error");
    } catch(e){console.error("Delete:",e);showToastMsg("Could not delete","error");}
    finally{setSaving(false);}
  }

  function resetForm() {
    setFormState(getDefaultForm()); setStep(0); setErrors({}); setShowSuccess(false);
    setEditTarget(null); setScreen("home"); setEntryType("funzone");
  }

  const dateStr = new Date().toLocaleDateString("en-IN",{weekday:"short",day:"2-digit",month:"short",year:"numeric"});

  // =========================================================================
  // RENDER
  // =========================================================================
  return (
    <div style={{maxWidth:420,margin:"0 auto",background:C.bg,minHeight:"100vh",fontFamily:"'Nunito',sans-serif",position:"relative"}}>

      {toast && <div style={{position:"fixed",top:16,left:"50%",transform:"translateX(-50%)",zIndex:200,background:toast.type==="success"?C.green:toast.type==="error"?C.danger:C.blue,color:"#fff",padding:"10px 20px",borderRadius:14,fontSize:13,fontWeight:700,boxShadow:C.shadowLift,animation:"popIn .3s ease",maxWidth:340}}>{toast.msg}</div>}

      {saving && <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.25)",backdropFilter:"blur(3px)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:150}}>
        <div style={{background:C.card,borderRadius:20,padding:"24px 32px",textAlign:"center",boxShadow:C.shadowLift,animation:"popIn .3s ease"}}>
          <Spinner size={32} /><div style={{marginTop:12,fontSize:14,fontWeight:700,color:C.textMid}}>Saving to Sheet...</div>
        </div></div>}

      {showSuccess && <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.4)",backdropFilter:"blur(8px)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:100,padding:20,animation:"fadeIn .3s ease"}}>
        <div style={{background:C.card,borderRadius:24,padding:"36px 28px",textAlign:"center",maxWidth:340,width:"100%",boxShadow:C.shadowLift,animation:"popIn .5s ease"}}>
          <div style={{width:80,height:80,margin:"0 auto 20px",borderRadius:"50%",background:C.greenSoft,display:"flex",alignItems:"center",justifyContent:"center"}}>
            <svg width="40" height="40" viewBox="0 0 40 40" fill="none"><path d="M10 20 L17 27 L30 14" stroke={C.green} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="40" strokeDashoffset="40" style={{animation:"checkDraw .6s ease .3s forwards"}} /></svg>
          </div>
          <h2 style={{margin:"0 0 8px",fontSize:22,fontWeight:800}}>Entry Saved!</h2>
          <p style={{margin:"0 0 4px",fontSize:14,color:C.textMid}}><strong>{form.customerName}</strong></p>
          <p style={{margin:"0 0 24px",fontSize:28,fontWeight:800,color:C.green}}>₹{totalAmount.toLocaleString("en-IN")}</p>
          <button onClick={()=>{setFormState(getDefaultForm());setStep(0);setShowSuccess(false);setEntryType("funzone");}} style={{width:"100%",padding:14,borderRadius:14,border:"none",background:C.accent,color:"#fff",fontSize:15,fontWeight:700,cursor:"pointer",marginBottom:10}}>+ Add Another</button>
          <button onClick={resetForm} style={{width:"100%",padding:14,borderRadius:14,border:`2px solid ${C.border}`,background:"transparent",color:C.textMid,fontSize:14,fontWeight:600,cursor:"pointer"}}>Back to Home</button>
        </div></div>}

      {/* HOME */}
      {screen==="home" && <div style={{padding:"16px 20px 120px"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:20,paddingTop:4}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <div style={{width:40,height:40,borderRadius:12,background:`linear-gradient(135deg,${C.accent},${C.accentDark})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20}}>🎪</div>
            <div><div style={{fontSize:18,fontWeight:800}}>{CONFIG.APP_NAME}</div><div style={{fontSize:11,color:C.textLight}}>{dateStr}</div></div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:6,background:C.greenSoft,border:`1.5px solid ${C.green}40`,borderRadius:20,padding:"5px 12px",fontSize:11,fontWeight:700,color:C.green}}>
            <div style={{width:7,height:7,borderRadius:"50%",background:C.green}} />Online
          </div>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:20}}>
          {[{l:"Entries",v:todayEntries.length,i:"🎟️",bg:C.accentSoft},{l:"Revenue",v:`₹${todayEntries.reduce((a,e)=>a+(parseInt(e.amount||e["Amount"]||0)),0).toLocaleString("en-IN")}`,i:"💰",bg:C.greenSoft},{l:"Kids",v:todayEntries.reduce((a,e)=>a+(parseInt(e.numKids||e["No of kids"]||1)),0),i:"👶",bg:C.blueSoft}].map((s,i)=>
            <div key={i} style={{background:s.bg,borderRadius:16,padding:"14px 12px",textAlign:"center"}}>
              <div style={{fontSize:20,marginBottom:4}}>{s.i}</div><div style={{fontSize:16,fontWeight:800}}>{s.v}</div>
              <div style={{fontSize:10,color:C.textLight,textTransform:"uppercase",letterSpacing:.5}}>{s.l}</div>
            </div>)}
        </div>
        <div style={{background:C.card,borderRadius:18,padding:"16px 18px",border:`1px solid ${C.border}`}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
            <h3 style={{margin:0,fontSize:15,fontWeight:800}}>Today's Entries</h3>
            <button onClick={fetchToday} style={{padding:"5px 12px",borderRadius:8,border:`1px solid ${C.border}`,background:"transparent",fontSize:12,fontWeight:600,color:C.textMid,cursor:"pointer"}}>↻ Refresh</button>
          </div>
          <EntryList entries={todayEntries} onEdit={handleEdit} onDelete={handleDelete} loading={loading} />
        </div>
        <div style={{position:"fixed",bottom:24,left:"50%",transform:"translateX(-50%)",width:"calc(100% - 40px)",maxWidth:380,zIndex:50}}>
          <button onClick={()=>{setFormState(getDefaultForm());setEditTarget(null);setScreen("form");setStep(0);}} style={{width:"100%",padding:16,borderRadius:18,border:"none",background:`linear-gradient(135deg,${C.accent},${C.accentDark})`,color:"#fff",fontSize:16,fontWeight:800,cursor:"pointer",boxShadow:`0 6px 24px ${C.accent}50`,animation:"slideUp .4s ease"}}>+ New Entry</button>
        </div>
      </div>}

      {/* FORM */}
      {screen==="form" && <>
        <div style={{background:C.card,padding:"14px 20px 12px",borderBottom:`1px solid ${C.border}`,position:"sticky",top:0,zIndex:50}}>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
            <button onClick={resetForm} style={{background:"transparent",border:"none",color:C.accent,fontSize:14,fontWeight:700,cursor:"pointer"}}>← Back</button>
            <div style={{fontSize:15,fontWeight:800}}>{editTarget?"Edit Entry":"New Entry"}</div>
            <div style={{width:60}} />
          </div>
          <div style={{display:"flex",alignItems:"center",gap:4}}>
            {[0,1,2,3].map(i=><React.Fragment key={i}>
              <button onClick={()=>{if(i<step)setStep(i);}} style={{width:32,height:32,borderRadius:10,border:"none",fontSize:14,background:i<=step?(i===step?C.accent:C.green):C.border,color:i<=step?"#fff":C.textLight,fontWeight:700,cursor:i<step?"pointer":"default",display:"flex",alignItems:"center",justifyContent:"center"}}>{i<step?"✓":STEP_ICONS[i]}</button>
              {i<3&&<div style={{flex:1,height:3,borderRadius:2,background:i<step?C.green:C.border}} />}
            </React.Fragment>)}
          </div>
          <div style={{display:"flex",justifyContent:"space-between",marginTop:4}}>
            {STEP_LABELS.map((l,i)=><span key={l} style={{fontSize:10,fontWeight:i===step?800:500,color:i===step?C.accent:C.textLight}}>{l}</span>)}
          </div>
        </div>

        <div ref={containerRef} style={{padding:"20px 20px 120px",overflowY:"auto"}}>
          <div style={{animation:shakeStep?"shake .4s ease":"springIn .45s ease"}}>

            {step===0&&<>
              <div style={{marginBottom:20}}>
                <div style={{fontSize:12,fontWeight:700,color:C.textLight,textTransform:"uppercase",letterSpacing:.8,marginBottom:10}}>Entry Type</div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                  {CONFIG.ENTRY_TYPES.map(t=><button key={t.key} onClick={()=>setEntryType(t.key)} style={{padding:"14px 12px",borderRadius:14,border:`2px solid ${entryType===t.key?t.color:C.border}`,background:entryType===t.key?`${t.color}12`:C.card,cursor:"pointer",display:"flex",alignItems:"center",gap:10}}>
                    <span style={{fontSize:24}}>{t.icon}</span><span style={{fontSize:14,fontWeight:entryType===t.key?800:500,color:entryType===t.key?t.color:C.textMid}}>{t.label}</span>
                  </button>)}
                </div>
              </div>
              <InputField label="Customer Name" icon="👤" error={errors.customerName}>
                <input value={form.customerName} onChange={e=>set("customerName",e.target.value)} placeholder="e.g. Priya - Kid 1" onFocus={()=>setFocusedField("name")} onBlur={()=>setFocusedField(null)} style={inputStyle(focusedField==="name",errors.customerName)} />
              </InputField>
              <InputField label="Number of Kids" icon="👶"><NumberStepper value={form.numKids} onChange={v=>set("numKids",v)} min={1} max={10} label="kids" /></InputField>
              <InputField label="Phone Number" icon="📱">
                <input value={form.phone} onChange={e=>set("phone",e.target.value.replace(/\D/g,"").slice(0,10))} placeholder="10-digit mobile" type="tel" inputMode="numeric" onFocus={()=>setFocusedField("phone")} onBlur={()=>setFocusedField(null)} style={inputStyle(focusedField==="phone")} />
              </InputField>
              <InputField label="Date of Birth (Child)" icon="🎂">
                <input value={form.dob} onChange={e=>set("dob",e.target.value)} type="date" onFocus={()=>setFocusedField("dob")} onBlur={()=>setFocusedField(null)} style={inputStyle(focusedField==="dob")} />
              </InputField>
            </>}

            {step===1&&<>
              <InputField label="Amount per Kid (₹)" icon="💰" error={errors.amount}>
                <div style={{position:"relative"}}>
                  <span style={{position:"absolute",left:16,top:"50%",transform:"translateY(-50%)",fontSize:20,fontWeight:800,color:C.accent}}>₹</span>
                  <input value={form.amount} onChange={e=>set("amount",e.target.value.replace(/\D/g,""))} type="tel" inputMode="numeric" placeholder="300" onFocus={()=>setFocusedField("amount")} onBlur={()=>setFocusedField(null)} style={{...inputStyle(focusedField==="amount",errors.amount),paddingLeft:40,fontSize:24,fontWeight:800}} />
                </div>
              </InputField>
              <div style={{display:"flex",flexWrap:"wrap",gap:8,marginBottom:18}}>
                {CONFIG.AMOUNT_PRESETS.map(a=><button key={a} onClick={()=>set("amount",String(a))} style={{padding:"8px 14px",borderRadius:10,border:`1.5px solid ${form.amount===String(a)?C.accent:C.border}`,background:form.amount===String(a)?C.accentSoft:"transparent",color:form.amount===String(a)?C.accent:C.textMid,fontSize:13,fontWeight:700,cursor:"pointer"}}>₹{a}</button>)}
              </div>
              <InputField label="Payment Mode" icon="💳" error={errors.mop}><ChipSelect options={CONFIG.MOP_OPTIONS} value={form.mop} onChange={v=>set("mop",v)} /></InputField>
              <InputField label="Socks (₹ per pair)" icon="🧦">
                <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                  {CONFIG.SOCKS_PRICES.map(p=><button key={p} onClick={()=>{set("socks",p);if(p>0&&!form.socksMop)set("socksMop",form.mop);}} style={{padding:"10px 18px",borderRadius:12,border:`2px solid ${form.socks===p?C.accent:C.border}`,background:form.socks===p?C.accentSoft:C.card,color:form.socks===p?C.accent:C.textMid,fontSize:14,fontWeight:700,cursor:"pointer"}}>{p===0?"None":`₹${p}`}</button>)}
                </div>
              </InputField>
              {form.socks>0&&<InputField label="Socks Payment Mode" icon="🔄"><ChipSelect options={CONFIG.MOP_OPTIONS} value={form.socksMop} onChange={v=>set("socksMop",v)} /></InputField>}
              <div style={{background:`linear-gradient(135deg,${C.accent}10,${C.accentSoft})`,borderRadius:16,padding:"16px 18px",border:`2px solid ${C.accent}30`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <div><div style={{fontSize:11,color:C.textLight,fontWeight:600,textTransform:"uppercase"}}>Total Amount</div><div style={{fontSize:11,color:C.textLight}}>{form.numKids} kid{form.numKids>1?"s":""} × ₹{form.amount}{form.socks>0?` + ₹${form.socks}`:""}</div></div>
                <div style={{fontSize:28,fontWeight:900,color:C.accent}}>₹{totalAmount.toLocaleString("en-IN")}</div>
              </div>
            </>}

            {step===2&&<>
              <InputField label="Duration" icon="⏱️"><ChipSelect options={CONFIG.HOUR_OPTIONS} value={form.hours} onChange={v=>set("hours",v)} /></InputField>
              <InputField label="Time In" icon="🕐">
                <input value={form.timeIn} onChange={e=>set("timeIn",e.target.value)} type="time" onFocus={()=>setFocusedField("timein")} onBlur={()=>setFocusedField(null)} style={{...inputStyle(focusedField==="timein"),fontSize:20,fontWeight:700,textAlign:"center"}} />
              </InputField>
              {form.timeIn&&<div style={{background:C.blueSoft,borderRadius:14,padding:"14px 18px",border:`1.5px solid ${C.blue}30`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <div><div style={{fontSize:11,color:C.blue,fontWeight:600,textTransform:"uppercase"}}>Expected Time Out</div><div style={{fontSize:10,color:C.textLight}}>{form.hours} hr session</div></div>
                <div style={{fontSize:22,fontWeight:800,color:C.blue}}>{computeTimeOut(form.timeIn,form.hours)}</div>
              </div>}
            </>}

            {step===3&&<>
              <div style={{fontSize:14,fontWeight:700,color:C.textMid,marginBottom:14,textTransform:"uppercase",letterSpacing:.8}}>Review Entry</div>
              {[
                {l:"Type",v:CONFIG.ENTRY_TYPES.find(t=>t.key===entryType)?.label,i:CONFIG.ENTRY_TYPES.find(t=>t.key===entryType)?.icon},
                {l:"Customer",v:form.customerName,i:"👤"},{l:"Kids",v:form.numKids,i:"👶"},
                {l:"Amount/Kid",v:`₹${form.amount}`,i:"💰"},
                ...(form.socks>0?[{l:"Socks",v:`₹${form.socks} (${form.socksMop})`,i:"🧦"}]:[]),
                {l:"Payment",v:form.mop,i:"💳"},{l:"Duration",v:`${form.hours} hr`,i:"⏱️"},
                {l:"Timing",v:`${form.timeIn} → ${computeTimeOut(form.timeIn,form.hours)}`,i:"🕐"},
                ...(form.phone?[{l:"Phone",v:form.phone,i:"📱"}]:[]),
                ...(form.dob?[{l:"DOB",v:form.dob,i:"🎂"}]:[]),
              ].map((r,i)=><div key={i} style={{display:"flex",alignItems:"center",padding:"12px 0",borderBottom:`1px solid ${C.border}`}}>
                <span style={{fontSize:18,marginRight:12,width:28,textAlign:"center"}}>{r.i}</span>
                <span style={{fontSize:13,color:C.textLight,flex:1,fontWeight:500}}>{r.l}</span>
                <span style={{fontSize:14,fontWeight:700}}>{r.v}</span>
              </div>)}
              <div style={{marginTop:18,background:`linear-gradient(135deg,${C.green}10,${C.greenSoft})`,borderRadius:16,padding:"18px 20px",border:`2px solid ${C.green}40`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <div style={{fontSize:14,fontWeight:700,color:C.green}}>Grand Total</div>
                <div style={{fontSize:30,fontWeight:900,color:C.green}}>₹{totalAmount.toLocaleString("en-IN")}</div>
              </div>
            </>}
          </div>
        </div>

        <div style={{position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:420,padding:"14px 20px 24px",background:`linear-gradient(to top,${C.bg} 70%,transparent)`,display:"flex",gap:10,zIndex:50}}>
          {step>0&&<button onClick={prev} style={{flex:.4,padding:16,borderRadius:16,border:`2px solid ${C.border}`,background:C.card,color:C.textMid,fontSize:15,fontWeight:700,cursor:"pointer"}}>Back</button>}
          <button disabled={saving} onClick={step===3?(editTarget?handleUpdateSubmit:submitEntry):next} style={{flex:1,padding:16,borderRadius:16,border:"none",background:step===3?`linear-gradient(135deg,${C.green},#15b577)`:`linear-gradient(135deg,${C.accent},${C.accentDark})`,color:"#fff",fontSize:16,fontWeight:800,cursor:saving?"wait":"pointer",boxShadow:`0 4px 20px ${step===3?C.green:C.accent}40`,opacity:saving?.7:1}}>
            {step===3?(editTarget?"✓ Update Entry":"✓ Save Entry"):`Next → ${STEP_LABELS[step+1]}`}
          </button>
        </div>
      </>}
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));
